The folder are codes written by Tejas Shanbhag for ECEN 5273
Here we have codes for client and server sides using User Datagram protocol.
We have to implement five commands on the client side so as to get the results from or to the servers side.
The commands are 
get, put,delete,ls,exit 
For commands get, put and delete we need both command and filename.
We differentiate these wrt to a delimiter. In my code I used ":"
As result, we use strstr function to check if we have a delimiter and then differntiate it with strtok
Now, after identifying what command was passed, I implemented reliabilitity using stop and wait protocol.
Every time a packet is sent, it is sent with a packet number in a structure. This is received at the receiver side and checked if the same ack has come, if not, we send the same packet again. This can be due to packet loss or ack loss 
Also, if an ack is not received within a Round Trip Time, data is retransmitted. 
We open File pointers for reading and writing in rb and wb mode for binary files as well.
Similarly for put, we put a file from client to reciever.
For delete, we have used a remove function on the server side.
For ls, we open a directory and list all the files in the directory at the servers side and send it back to the receiver.
For exit, we just close the socket at the receiver side.
The packet size can be changed although I have only tried with 512 and 1024 bytes.
Encryption with Exor method added where the data is exored by a key
File transfers upto 30MB have been checked.

